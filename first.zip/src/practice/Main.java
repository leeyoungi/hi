package practice;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scan=new Scanner(System.in);
     
     int a=scan.nextInt();
     int b=scan.nextInt();
     int c=scan.nextInt();
     
   
     System.out.println();
  
	}

}
