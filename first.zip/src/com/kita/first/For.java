package com.kita.first;

public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=0; i<10;i++) { //1번째값은 초기값 2번째는 조건 3번째는 증감식
	System.out.println(i+"반복문!!");
}
	}

}
