package com.kita.first.level6;

public class PlayerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\

		Player player = new CDPlayer();
		player.play();
		player = new DVDplayer();

		player.play();
	}

}
