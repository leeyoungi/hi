package com.kita.first.level5;

public class Dog  extends Animal{

	@Override
	public void cry() {
		System.out.println("멍멍!");
	}

}
