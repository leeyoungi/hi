package com.kita.first.level5;

public class Animal {
	public void cry() {}
}
