package com.kita.first.level5;

public class Sparrow extends Animal {
	@Override
	public void cry() {
		System.out.println("짹짹!");
	}
}