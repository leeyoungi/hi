package com.kita.first.level5;

public class Cat extends Animal {
	@Override
	public void cry() {
		System.out.println("야옹~~");
	}
	
	public void sleep() {
		System.out.println("고양이 잔다~~~");
	}
}
