package com.kita.first;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		// while은 ()안에 조건 
		// while 문 위에 초기 변수 선언
		// 어떤 조건인 동안 ++ 되는경우 사용
 while(i<5) {
    System.out.println(i+1);
    i++;
 }
	}

}
