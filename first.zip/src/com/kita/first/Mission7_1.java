package com.kita.first;

public class Mission7_1 {
/*while문에 조건식을 이용하여 
 * 1 ~ 100을 모두 더한 값이 출력되도록 하세요.
 * 
 * 
 * 
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int i=0;
	int sum=0;
		while(i<=100) {
			
				 
			sum=sum+i;
			i++;
			}
			
	System.out.println("합계 :"+sum);

	}

}
