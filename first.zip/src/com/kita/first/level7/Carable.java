package com.kita.first.level7;

public interface Carable {

}
