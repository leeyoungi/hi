package com.kita.first.level7;

public interface AttackUnit {
//인터페이스가 인터페이스 상속 받을 떄는  extends
	//인터페이스는 객체화x
	void  attack(Unit u);

}
