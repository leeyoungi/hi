package  com.kita.first;

public class first {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("헬로우 월드!!");
		System.out.println("저의 이름은 이윤기입니다");
	 
		
	
		
	//	/* */은 다중라인
		//은 싱글라인
	}

}

