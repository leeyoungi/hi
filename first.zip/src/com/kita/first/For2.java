package com.kita.first;

public class For2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
	for(int i=0;i<3; i++) {
		for(int z=0; z<5; z++) {
			
		for(int r=0;r<3;++r) {
			System.out.printf("%d - %d -%d \n",i,z,r);
		}
		}
	}
		
		
		
	}

}
