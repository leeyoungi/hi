package com.kita.first;

public class Mission6_3 {
   // 2 ~ 9 
	

	// 단 !! 단이 바뀔 때 개행을 해줘야함
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        

	   
	
		
		for( int i=26;i<34;i++) {
			for(int j=1;j<10;j++) {
			System.out.printf("%d * %d = %d\n",i-24,j,(i-24)*j);
			}
			System.out.println("==============");
		}
		
	}

}
