package com.kita.first;

public class sdsdd {
	private int a;
	private int b;

	public int getSum() {
		return a;
	}

	public void setSum(int a, int b) {
		this.a = a;
		this.b = b;
		System.out.println(a+b);
	}

}
