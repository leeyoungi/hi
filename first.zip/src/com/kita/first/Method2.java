package com.kita.first;

public class Method2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           System.out.println("args.length:"+args.length);
           for(int i=0;i<args.length;i++) {
        	   System.out.println(args[i]);
           }
	}

}
