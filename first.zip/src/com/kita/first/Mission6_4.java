package com.kita.first;

public class Mission6_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i < 10; i++) {

			for (int j = 2; j < 10; j++) {

				System.out.printf("%d * %d = %d", j, i, j * i);
				
				System.out.print("\t");
			
			}

			System.out.println();
		}
	}

}
