package com.kita.first;

public class Continue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    
		for(int i=0; i<20; i++) {
			if(i==5) {
				continue;
			}
				System.out.println(i);
			}
		
			
	}

}
