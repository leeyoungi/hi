package com.kita.first;

import java.util.Scanner;

public class Mission6_1 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int dan=4;
	   
	
		
		for( int i=14;i<23;i++) {
			
			System.out.printf("%d * %d= %d\n",dan,(i-13),dan*(i-13));
			
		}

	}

}
