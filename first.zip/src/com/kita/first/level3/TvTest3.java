package com.kita.first.level3;

public class TvTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Tv[]tvArr=new Tv[3];
       tvArr[0]=new Tv();
       tvArr[1]=new Tv();
       tvArr[2]=new Tv();
       System.out.println( tvArr[2]);
	}

}
