package com.kita.first.level4;

public class AnimalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Animal animal = new Animal();
				//Bird bird = new Bird("참새");
				//Bird bird2 = new Bird("기러기");
				//Bird bird3 = new Bird(); 
				
				//animal.crying();
				//animal.flying();
				//bird.crying();
				//bird.flying();
				
				Sparrow sparrow = new Sparrow();
				sparrow.whoAmI();
		  
		 
		
	}

}
