package com.kita.first.level4;
import com.kita.first.level4.Animal;
import com.kita.first.level4.Bird;

public class Sparrow  extends Bird{

	public Sparrow() {
		super("참새");
		// TODO Auto-generated constructor stub
	}

	
}
