package com.kita.first.level4;

public class ClassTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassC clsC = new ClassC();
		clsC.write();
	}

}
