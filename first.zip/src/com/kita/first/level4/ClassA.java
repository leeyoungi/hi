package com.kita.first.level4;

public class ClassA extends Object{
	public ClassA() {
		super();
		System.out.println("나 classA요");
	}
	
	void print() {
		System.out.println("A");
	}
	void write(){
		System.out.println("에이를 쓰다");
	}
}
