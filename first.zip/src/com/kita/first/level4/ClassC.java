package com.kita.first.level4;

public class ClassC extends ClassB{
	public ClassC(){
		super();
		System.out.println("나 ClassC요.");
	}
	public void print() {
		System.out.println("C");
	}
}
