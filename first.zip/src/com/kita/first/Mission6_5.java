package com.kita.first;

public class Mission6_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int star=4;
        
        
        for(int i=0; i<4; i++) {
        for(int j=0; j<star; j++) {
        	System.out.print("*");
        }
        	System.out.println();
        }
	}

}
