package com.kita.level2;

public class p {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
	for(int a=0;a<10;a++) {	
		
		if(a-1==0) {
			System.out.println("*");
		}
		
	}

}
}