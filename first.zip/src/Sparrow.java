
import com.kita.first.level4.Bird;

public class Sparrow extends Bird {

	public Sparrow(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
